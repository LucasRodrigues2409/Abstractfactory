package refactoring_guru.abstract_factory.example.buttons;

//Variante da interface button focada no sistema operacinal Windows
public class WindowsButton implements Button {

    @Override
    public void paint() {
        System.out.println("You have created WindowsButton.");
    }
}
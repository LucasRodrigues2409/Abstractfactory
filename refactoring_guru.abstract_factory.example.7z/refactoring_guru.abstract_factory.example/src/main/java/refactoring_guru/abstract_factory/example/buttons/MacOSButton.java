package refactoring_guru.abstract_factory.example.buttons;

//Variante da interface button focada no sistema operacinal MAC
public class MacOSButton implements Button {

    @Override
    public void paint() {
        System.out.println("You have created MacOSButton.");
    }
}
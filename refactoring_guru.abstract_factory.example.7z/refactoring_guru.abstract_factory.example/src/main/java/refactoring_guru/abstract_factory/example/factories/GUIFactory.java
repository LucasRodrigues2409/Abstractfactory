package refactoring_guru.abstract_factory.example.factories;

import refactoring_guru.abstract_factory.example.buttons.Button;
import refactoring_guru.abstract_factory.example.checkboxes.Checkbox;

//Factory abstrata que conhece todos os tipos de produtos Abstratos
public interface GUIFactory {
    Button createButton();
    Checkbox createCheckbox();
}
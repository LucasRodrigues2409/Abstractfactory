package refactoring_guru.abstract_factory.example.checkboxes;

//Variante da interface Checkbox focada no sistema operacinal MAC
public class MacOSCheckbox implements Checkbox {

    @Override
    public void paint() {
        System.out.println("You have created MacOSCheckbox.");
    }
}
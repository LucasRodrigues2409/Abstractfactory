package refactoring_guru.abstract_factory.example.buttons;
 
//criação de uma interface abstrata com o nome Button
public interface Button {
    void paint();
}

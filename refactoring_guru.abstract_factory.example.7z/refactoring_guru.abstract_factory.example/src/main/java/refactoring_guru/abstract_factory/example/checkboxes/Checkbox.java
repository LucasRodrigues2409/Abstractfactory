package refactoring_guru.abstract_factory.example.checkboxes;

//criação de uma interface abstrata com o nome Checkbox
public interface Checkbox {
    void paint();
}